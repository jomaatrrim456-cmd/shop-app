مشروع تطبيق إدارة المحل للأندرويد.

طريقة البناء من AndroidIDE:
1) فك ضغط المشروع.
2) افتح مجلد ShopManager كمشروع Gradle.
3) انتظر مزامنة Gradle وتنزيل الأدوات المطلوبة.
4) من قائمة Build اختر Assemble Debug أو Build APK.
5) ستجد ملف APK داخل app/build/outputs/apk/debug/.

الموقع موجود داخل app/src/main/assets/index.html.
